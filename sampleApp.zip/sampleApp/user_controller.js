app=angular.module('mymodule',['sermodule'])
app.controller('userController',function($scope,userService) {

    $scope.users=userService.showUsers();

    $scope.addUser=function() {
userService.addUser($scope.user)
     $scope.user={};
    }

    $scope.deleteUser=function(id) {
userService.deleteUser(id);
        
                //$scope.user={};
    }

    $scope.updateUser=function(id) {
     
                $scope.user=angular.copy(userService.updateUser(id));
    }
    
})

app.directive('welcomeMessage',function()
{
    return{
        restrict : 'AE',
        replace : 'true',
        template : '<h3> This is copyright</h3>'
    };
});



app.directive('myPicker', function() {
    return {
		restrict: 'A', 
		require: 'ngModel',
       
        link : function (scope, element, attrs, ngModelCtrl) {
            $(function(){
                element.datepicker({
                    dateFormat:'dd/mm/yy',
                    onSelect:function (mydat) {
                        ngModelCtrl.$setViewValue(mydat);
						
                        scope.$digest();
                    }
                });
            });
        }
    }
});

app.directive('ngCompare', [function () {
	return {
			  require: 'ngModel',
			  link: function (scope, elem, attrs, ngModelCtrl) {
					var firstfield = "#" + attrs.ngCompare;
		
					//second field key up
					elem.on('keyup', function () {
					scope.$apply(function () {
					var isMatch = elem.val() === $(firstfield).val();
					ngModelCtrl.$setValidity('valueMatch', isMatch);
					console.log(firstfield);
					});
					});
   
					
				  }
			}
	}]);