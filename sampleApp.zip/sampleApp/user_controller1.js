angular.module('um',['sermodule']).controller('uc', function($scope)
{

    var uid = 1;
    $scope.user=[];
    
$scope.adduser = function(){ 
     
if($scope.user.id == null)
{
    $scope.user.id=uid++;
    $scope.user.push($scope.users);
    $scope.user = [];
}

else
{
    for(i in $scope.users)
    {
        if($scope.users[i].id == $scope.users.id )
        {
            $scope.users[i]=$scope.user;
         
        }
    }
}
   
    
}

$scope.deleteUser=function(id){

    for(i in $scope.users)
    {
        if($scope.users[i].id == $scope.users.id )
        {
            $scope.users.splice(i,1);
            $scope.user = [];
        }
    }


}

$scope.updateUser=(id)=>{

    if($scope.users[i].id == $scope.users.id )
    {
        $scope.users.angular.copy($scope.users[i]);
        
    }


}

})