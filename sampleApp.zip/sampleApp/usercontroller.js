angular.module('mymodule',[])
.controller('userController',function($scope) {
var uid=1;
    $scope.users=[];

	$scope.addUser=function() {
if($scope.user.id==null) {
	$scope.user.id=uid++;
     $scope.users.push($scope.user)
		 
} else {
	for(i in $scope.users) {
			if($scope.users[i].id==$scope.user.id) {
	$scope.users[i]=$scope.user;
			}}}
     $scope.user={};
    }

	$scope.deleteUser=function(id) {

		for(i in $scope.users) {
			if($scope.users[i].id==id) {
				$scope.users.splice(i,1);
				$scope.user={};
	}}}

	$scope.updateUser=function(id) {
     for(i in $scope.users) {
			if($scope.users[i].id==id) {
				$scope.user=angular.copy($scope.users[i]);
	}}}
    
});