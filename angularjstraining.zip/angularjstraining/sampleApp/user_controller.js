angular.module('mymodule',['sermodule'])
.controller('userController',function($scope,userService) {

    $scope.users=userService.showUsers();

    $scope.addUser=function() {
userService.addUser($scope.user)
     $scope.user={};
    }

	$scope.deleteUser=function(id) {
userService.deleteUser(id);
		
				//$scope.user={};
	}

	$scope.updateUser=function(id) {
     
				$scope.user=angular.copy(userService.updateUser(id));
	}
    
});