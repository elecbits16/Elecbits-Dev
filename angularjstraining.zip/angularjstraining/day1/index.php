<html>
    <head>
        <script 
        src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.4/angular.min.js">
        </script>
    <script
    src="user_controller.js"></script>   


</head>

<body>

<div ng-app = "um">
    <div ng-controller="uc">
Name : <input type="text" ng-model="amdocs.uname" />
Email : <input type="text" ng-model="amdocs.email" />
City : <input type="text" ng-model="amdocs.city" />

<br>
<button ng-click="adduser()">Add Users</button>

<ul>
<li ng-repeat="u in users" >
{{u.uname}},{{u.email}},{{u.city}}
</li>
</ul>
</div>
</div>

</body>



    </html>
