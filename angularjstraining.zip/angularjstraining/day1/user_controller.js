angular.module('um',[]).controller('uc', function($scope)
{
    $scope.users=[];
    
$scope.adduser = function(){ 
     
    $scope.users.push($scope.amdocs);
    $scope.amdocs={};
}

})